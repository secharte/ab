package jason.asSyntax;

/** The interface for string terms of the AgentSpeak language */
public interface StringTerm extends Term {
	public String getString();
	public int length();
}
